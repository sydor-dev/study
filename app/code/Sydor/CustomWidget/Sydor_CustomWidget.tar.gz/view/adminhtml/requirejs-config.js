var config = {
    map: {
        '*': {
            'Sydor_CustomWidget/js/sku-search': 'Sydor_CustomWidget/js/sku-search'
        }
    }
};
